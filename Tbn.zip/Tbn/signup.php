<!DOCTYPE html>
<html>
<head>
	<title>Sign Up Form</title>
</head>
<body>
	<h1>Sign Up Form</h1>
	<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		<label for="name">Name:</label>
		<input type="text" id="name" name="name"><br><br>
		<label for="email">Email:</label>
		<input type="email" id="email" name="email"><br><br>
		<label for="password">Password:</label>
		<input type="password" id="password" name="password"><br><br>
		<input type="submit" value="Sign Up">
	</form>

	<?php
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$name = $_POST['name'];
			$email = $_POST['email'];
			$password = $_POST['password'];

			if (empty($name) || empty($email) || empty($password)) {
				echo '<p style="color:red;">All fields are required.</p>';
			} else {
				echo '<p style="color:green;">Thanks for signing up, ' . $name . '!</p>';
			}
		}
	?>
</body>
</html>