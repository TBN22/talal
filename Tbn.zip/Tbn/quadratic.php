<?php
// Quadratic equation: ax^2 + bx + c = 0

$a = 2;
$b = 5;
$c = 2;

$discriminant = $b * $b - 4 * $a * $c;

switch (true) {
  case ($discriminant > 0):
    $root1 = (-$b + sqrt($discriminant)) / (2 * $a);
    $root2 = (-$b - sqrt($discriminant)) / (2 * $a);
    echo "The roots are real and distinct: " . $root1 . " and " . $root2;
    break;
  case ($discriminant == 0):
    $root = -$b / (2 * $a);
    echo "The root is real and equal: " . $root;
    break;
  default:
    $realPart = -$b / (2 * $a);
    $imaginaryPart = sqrt(-$discriminant) / (2 * $a);
    echo "The roots are complex and conjugate: " . $realPart . " + " . $imaginaryPart . "i and " . $realPart . " - " . $imaginaryPart . "i";
}

// Alternatively, we could use if else statements to achieve the same result:

if ($discriminant > 0) {
  $root1 = (-$b + sqrt($discriminant)) / (2 * $a);
  $root2 = (-$b - sqrt($discriminant)) / (2 * $a);
  echo "The roots are real and distinct: " . $root1 . " and " . $root2;
} else if ($discriminant == 0) {
  $root = -$b / (2 * $a);
  echo "The root is real and equal: " . $root;
} else {
  $realPart = -$b / (2 * $a);
  $imaginaryPart = sqrt(-$discriminant) / (2 * $a);
  echo "The roots are complex and conjugate: " . $realPart . " + " . $imaginaryPart . "i and " . $realPart . " - " . $imaginaryPart . "i";
}
?>