const form = document.getElementById('myForm');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');

form.addEventListener('submit', (event) => {
  event.preventDefault();

  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  if (name === '') {
    alert('Name field cannot be empty.');
    nameInput.focus();
    return false;
  }

  if (email === '') {
    alert('Email field cannot be empty.');
    emailInput.focus();
    return false;
  }

  if (!isValidEmail(email)) {
    alert('Invalid email format.');
    emailInput.focus();
    return false;
  }

  if (password === '') {
    alert('Password field cannot be empty.');
    passwordInput.focus();
    return false;
  }

  if (password.length < 8) {
    alert('Password must be at least 8 characters long.');
    passwordInput.focus();
    return false;
  }

  // If all fields are valid, submit the form
  form.submit();
});

function isValidEmail(email) {
  // Regular expression to validate email format
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailPattern.test(email);
}

$(document).ready(function() {
    $('#myForm').submit(function(event) {
      event.preventDefault();
  
      const name = $('#name').val().trim();
      const email = $('#email').val().trim();
      const password = $('#password').val().trim();
  
      if (name === '') {
        alert('Name field cannot be empty.');
        $('#name').focus();
        return false;
      }
  
      if (email === '') {
        alert('Email field cannot be empty.');
        $('#email').focus();
        return false;
      }
  
      if (!isValidEmail(email)) {
        alert('Invalid email format.');
        $('#email').focus();
        return false;
      }
  
      if (password === '') {
        alert('Password field cannot be empty.');
        $('#password').focus();
        return false;
      }
  
      if (password.length < 8) {
        alert('Password must be at least 8 characters long.');
        $('#password').focus();
        return false;
      }
  
      // If all fields are valid, submit the form
      $('#myForm')[0].submit();
    });
  });
  
  function isValidEmail(email) {
    // Regular expression to validate email format
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
  }