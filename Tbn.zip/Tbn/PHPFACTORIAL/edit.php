<?php
include 'conn.php';

// Check if the edit form is submitted
if (isset($_POST['edit_submit'])) {
  $id = $_POST['id'];
  $name = $_POST['name'];
  $email = $_POST['email'];
  $mobile = $_POST['mobile'];
  $password = $_POST['password'];

  // Update the row in the database
  $sql = "UPDATE tblcrud SET name='$name', email='$email', mobile='$mobile', password='$password' WHERE ID='$id'";
  $result = mysqli_query($con, $sql);

  if ($result) {
    echo "Data Updated Successfully";
  } else {
    echo "Data not updated";
  }
}

?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

  <title>Display</title>
</head>

<body>
  <div class="container my-5">
    <button type="button" class="btn btn-primary" onclick="location.href='add_user.php';">Add User</button>


    <table class="table">
      <thead>
        <tr>
          <th scope="col">Id</th>
          <th scope="col">Name</th>
          <th scope="col">Email</th>
          <th scope="col">Mobile</th>
          <th scope="col">Password</th>
          <th scope="col">Operations</th>
        </tr>
      </thead>
      <tbody>

        <?php
        // Fetch all rows from the table
        $sql = "SELECT * FROM tblcrud";
        $result = mysqli_query($con, $sql);
        if ($result) {

          while ($row = mysqli_fetch_assoc($result)) {
            $id = $row['ID'];
            $name = $row['name'];
            $email = $row['email'];
            $mobile = $row['mobile'];
            $password = $row['password'];

            // Generate the edit button
            $edit_button = "<button type='button' class='btn btn-success' onclick=\"location.href='edit_user.php?id=$id';\">Edit</button>";

            echo  "<tr>
            <td> $id </td>
            <td> $name </td>
            <td> $email </td>
            <td> $mobile </td>
            <td> $password </td>
            <td> $edit_button </td>
            </tr>";
          }
        }

        ?>

      </tbody>
    </table>

  </div>

</body>

</html>
