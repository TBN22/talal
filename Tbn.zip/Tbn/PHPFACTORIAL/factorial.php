
<?php

 $num=5;
 $fact=1;

 for($i=$num;$i>0;$i--)
 {
    $fact=$fact*$i;
    

 }
 echo "Factorial Sum is: ".$fact;
 ?>