<?php

// Connection to the database
$con = mysqli_connect('localhost', 'root', '', 'crud');
if (!$con) {
    die(mysqli_error($con));
}

// Check if ID is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete row with the given ID
    $sql = "DELETE FROM `tblcrud` WHERE `ID`='$id'";
    $result = mysqli_query($con, $sql);

    // Check if deletion was successful
    if ($result) {
        echo "Row deleted successfully.";
    } else {
        echo "Error deleting row: " . mysqli_error($con);
    }
}

// Close database connection
mysqli_close($con);

?>